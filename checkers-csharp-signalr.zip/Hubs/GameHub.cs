using Microsoft.AspNetCore.SignalR;

namespace CheckersOnline.Hubs;

// Hub = מרכז תקשורת בין הדפדפנים לבין השרת
public class GameHub : Hub
{
    // שחקן מצטרף לחדר לפי קוד חדר
    public async Task JoinRoom(string roomCode)
    {
        await Groups.AddToGroupAsync(Context.ConnectionId, roomCode);

        // מודיעים לכל מי שבחדר ששחקן הצטרף
        await Clients.Group(roomCode).SendAsync("PlayerJoined", "שחקן הצטרף לחדר " + roomCode);
    }

    // שחקן שולח מהלך לשרת
    public async Task SendMove(string roomCode, int fromRow, int fromCol, int toRow, int toCol)
    {
        // השרת שולח את המהלך לכל השחקנים באותו חדר
        await Clients.Group(roomCode).SendAsync("ReceiveMove", fromRow, fromCol, toRow, toCol);
    }

    // התחלת משחק מחדש
    public async Task RestartGame(string roomCode)
    {
        await Clients.Group(roomCode).SendAsync("RestartGame");
    }
}
