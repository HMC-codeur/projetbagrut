using CheckersOnline.Hubs;

var builder = WebApplication.CreateBuilder(args);

// מוסיפים SignalR - זה מאפשר תקשורת בזמן אמת בין שני שחקנים
builder.Services.AddSignalR();

var app = builder.Build();

// מציג את הקבצים שבתוך wwwroot
app.UseDefaultFiles();
app.UseStaticFiles();

// כתובת החיבור של SignalR
app.MapHub<GameHub>("/gameHub");

app.Run();
