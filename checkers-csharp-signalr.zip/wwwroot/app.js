// ===============================
// חלק 1: חיבור לשרת C# SignalR
// ===============================

const connection = new signalR.HubConnectionBuilder()
  .withUrl("/gameHub")
  .build();

let currentRoom = "";
let isConnectedToRoom = false;

connection.start().then(() => {
  statusText.textContent = "מחובר לשרת. עכשיו תבחר חדר.";
});

// מקבלים הודעה כששחקן נכנס לחדר
connection.on("PlayerJoined", function (message) {
  statusText.textContent = message;
});

// מקבלים מהלך מהשרת
connection.on("ReceiveMove", function (fromRow, fromCol, toRow, toCol) {
  makeMoveLocal(fromRow, fromCol, toRow, toCol);
});

// מקבלים התחלה מחדש מהשרת
connection.on("RestartGame", function () {
  restartGameLocal();
});

function joinRoom() {
  const roomInput = document.getElementById("roomInput");
  currentRoom = roomInput.value.trim();

  if (currentRoom === "") {
    statusText.textContent = "צריך לכתוב קוד חדר.";
    return;
  }

  connection.invoke("JoinRoom", currentRoom);
  isConnectedToRoom = true;
  roomText.textContent = currentRoom;
  statusText.textContent = "נכנסת לחדר " + currentRoom;
}

function sendMoveToServer(fromRow, fromCol, toRow, toCol) {
  if (!isConnectedToRoom) {
    statusText.textContent = "קודם צריך להיכנס לחדר.";
    return;
  }

  connection.invoke("SendMove", currentRoom, fromRow, fromCol, toRow, toCol);
}

function askServerToRestart() {
  if (!isConnectedToRoom) {
    statusText.textContent = "קודם צריך להיכנס לחדר.";
    return;
  }

  connection.invoke("RestartGame", currentRoom);
}

// ===============================
// חלק 2: המשחק עצמו
// קל לשינוי, בלי קוד מסובך
// ===============================

const boardElement = document.getElementById("board");
const turnText = document.getElementById("turnText");
const scoreText = document.getElementById("scoreText");
const statusText = document.getElementById("statusText");
const roomText = document.getElementById("roomText");

let board = [];
let currentPlayer = "red";
let selectedPiece = null;
let possibleMoves = [];
let gameOver = false;

function createStartingBoard() {
  board = [];

  for (let row = 0; row < 8; row++) {
    board[row] = [];

    for (let col = 0; col < 8; col++) {
      board[row][col] = null;

      const isDarkCell = (row + col) % 2 === 1;

      if (isDarkCell && row < 3) {
        board[row][col] = { color: "black", king: false };
      }

      if (isDarkCell && row > 4) {
        board[row][col] = { color: "red", king: false };
      }
    }
  }
}

function renderBoard() {
  boardElement.innerHTML = "";

  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const cell = document.createElement("div");
      cell.className = "cell " + (((row + col) % 2 === 0) ? "light" : "dark");

      const isSelected = selectedPiece && selectedPiece.row === row && selectedPiece.col === col;
      const isPossible = possibleMoves.some(move => move.row === row && move.col === col);

      if (isSelected) cell.classList.add("selected");
      if (isPossible) cell.classList.add("possible");

      const piece = board[row][col];

      if (piece) {
        const pieceElement = document.createElement("div");
        pieceElement.className = "piece " + piece.color;
        pieceElement.textContent = piece.king ? "♛" : "";
        cell.appendChild(pieceElement);
      }

      cell.addEventListener("click", () => handleCellClick(row, col));
      boardElement.appendChild(cell);
    }
  }

  updateInfo();
}

function handleCellClick(row, col) {
  if (gameOver) return;

  if (!isConnectedToRoom) {
    statusText.textContent = "קודם תיכנס לחדר.";
    return;
  }

  const clickedPiece = board[row][col];

  if (selectedPiece) {
    const move = possibleMoves.find(m => m.row === row && m.col === col);

    if (move) {
      // לא מזיזים רק אצלנו.
      // שולחים לשרת, והשרת מחזיר את המהלך לשני השחקנים.
      sendMoveToServer(selectedPiece.row, selectedPiece.col, row, col);
      return;
    }
  }

  if (clickedPiece && clickedPiece.color === currentPlayer) {
    selectedPiece = { row, col };
    possibleMoves = getPossibleMoves(row, col);
    statusText.textContent = "בחרת כלי. עכשיו בחר משבצת ירוקה.";
    renderBoard();
  } else {
    selectedPiece = null;
    possibleMoves = [];
    statusText.textContent = "בחר כלי של השחקן שבתור.";
    renderBoard();
  }
}

function getPossibleMoves(row, col) {
  const piece = board[row][col];
  if (!piece) return [];

  const moves = [];
  const directions = [];

  if (piece.color === "red" || piece.king) {
    directions.push([-1, -1], [-1, 1]);
  }

  if (piece.color === "black" || piece.king) {
    directions.push([1, -1], [1, 1]);
  }

  for (const [rowDirection, colDirection] of directions) {
    const nextRow = row + rowDirection;
    const nextCol = col + colDirection;

    if (isInsideBoard(nextRow, nextCol) && board[nextRow][nextCol] === null) {
      moves.push({ row: nextRow, col: nextCol, capture: null });
    }

    const jumpRow = row + rowDirection * 2;
    const jumpCol = col + colDirection * 2;

    if (
      isInsideBoard(jumpRow, jumpCol) &&
      board[jumpRow][jumpCol] === null &&
      board[nextRow] &&
      board[nextRow][nextCol] &&
      board[nextRow][nextCol].color !== piece.color
    ) {
      moves.push({
        row: jumpRow,
        col: jumpCol,
        capture: { row: nextRow, col: nextCol }
      });
    }
  }

  return moves;
}

// זה המהלך האמיתי שמתבצע אחרי שהשרת אישר ושלח לכולם
function makeMoveLocal(fromRow, fromCol, toRow, toCol) {
  const capture = findCapture(fromRow, fromCol, toRow, toCol);
  const piece = board[fromRow][fromCol];

  if (!piece) return;

  board[toRow][toCol] = piece;
  board[fromRow][fromCol] = null;

  if (capture) {
    board[capture.row][capture.col] = null;
  }

  if (piece.color === "red" && toRow === 0) {
    piece.king = true;
  }

  if (piece.color === "black" && toRow === 7) {
    piece.king = true;
  }

  selectedPiece = null;
  possibleMoves = [];

  checkWinner();

  if (!gameOver) {
    currentPlayer = currentPlayer === "red" ? "black" : "red";
    statusText.textContent = capture ? "אכילה מוצלחת!" : "מהלך בוצע.";
  }

  renderBoard();
}

function findCapture(fromRow, fromCol, toRow, toCol) {
  const rowDifference = toRow - fromRow;
  const colDifference = toCol - fromCol;

  if (Math.abs(rowDifference) === 2 && Math.abs(colDifference) === 2) {
    return {
      row: fromRow + rowDifference / 2,
      col: fromCol + colDifference / 2
    };
  }

  return null;
}

function checkWinner() {
  let redCount = 0;
  let blackCount = 0;

  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const piece = board[row][col];
      if (!piece) continue;
      if (piece.color === "red") redCount++;
      if (piece.color === "black") blackCount++;
    }
  }

  if (redCount === 0) {
    gameOver = true;
    statusText.textContent = "השחור ניצח!";
  }

  if (blackCount === 0) {
    gameOver = true;
    statusText.textContent = "האדום ניצח!";
  }
}

function updateInfo() {
  let redCount = 0;
  let blackCount = 0;

  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const piece = board[row][col];
      if (!piece) continue;
      if (piece.color === "red") redCount++;
      if (piece.color === "black") blackCount++;
    }
  }

  scoreText.textContent = `אדום: ${redCount} | שחור: ${blackCount}`;

  if (currentPlayer === "red") {
    turnText.textContent = "אדום";
    turnText.className = "value turn-red";
  } else {
    turnText.textContent = "שחור";
    turnText.className = "value turn-black";
  }
}

function isInsideBoard(row, col) {
  return row >= 0 && row < 8 && col >= 0 && col < 8;
}

function restartGameLocal() {
  currentPlayer = "red";
  selectedPiece = null;
  possibleMoves = [];
  gameOver = false;
  statusText.textContent = "המשחק התחיל מחדש";
  createStartingBoard();
  renderBoard();
}

createStartingBoard();
renderBoard();
